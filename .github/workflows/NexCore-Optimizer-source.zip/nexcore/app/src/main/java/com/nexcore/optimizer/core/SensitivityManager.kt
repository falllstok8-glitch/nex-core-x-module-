package com.nexcore.optimizer.core

import android.content.Context
import android.provider.Settings

/**
 * Stores per-game X/Y response profiles inside NexCore.
 * Android does not expose a public API for changing another app's touch
 * coordinates or injecting a touch filter into a game. X/Y/smooth/deadzone
 * therefore remain profile values for display, tuning notes and telemetry.
 * POINTER_SPEED is a system mouse/stylus setting, not touchscreen sensitivity.
 */
class SensitivityManager(
    private val context: Context,
    private val shizuku: ShizukuManager
) {
    data class Profile(
        val x: Float = 1.0f,
        val y: Float = 1.0f,
        val smooth: Float = 0.5f,
        val deadzone: Int = 0,
        val pointerSpeed: Int = 0
    )

    companion object {
        val GAME_PROFILES = mapOf(
            "com.dts.freefireth" to Profile(x = 1.0f, y = 1.0f, smooth = 0.5f),
            "com.dts.freefiremax" to Profile(x = 1.0f, y = 1.0f, smooth = 0.5f),
            "com.tencent.ig" to Profile(x = 1.0f, y = 1.0f, smooth = 0.5f),
            "com.garena.game.codm" to Profile(x = 1.0f, y = 1.0f, smooth = 0.5f)
        )
    }

    private var active: Profile = Profile()

    fun apply(profile: Profile): Boolean {
        require(profile.x in 0.25f..2.5f)
        require(profile.y in 0.25f..2.5f)
        require(profile.smooth in 0.0f..1.0f)
        require(profile.deadzone in 0..20)
        require(profile.pointerSpeed in -7..7)

        active = profile
        Blackbox.log(
            "SENSI_PROFILE",
            "saved x=${profile.x} y=${profile.y} smooth=${profile.smooth} deadzone=${profile.deadzone}"
        )
        return true
    }

    fun applyForGame(pkg: String): Boolean = apply(GAME_PROFILES[pkg] ?: active)

    /** Applies only Android's pointer-device speed; it does not alter finger touch input. */
    fun applyPointerSpeed(speed: Int): Boolean {
        require(speed in -7..7)
        return try {
            val ok = if (shizuku.isAvailable()) {
                shizuku.putSetting("system", "pointer_speed", speed.toString())
            } else {
                Settings.System.putInt(context.contentResolver, Settings.System.POINTER_SPEED, speed)
            }
            Blackbox.log("POINTER", "pointer_speed=$speed result=$ok")
            ok
        } catch (e: Exception) {
            Blackbox.err("POINTER", e.message ?: "Unable to update pointer speed")
            false
        }
    }

    fun getCurrentPointerSpeed(): Int = try {
        Settings.System.getInt(context.contentResolver, Settings.System.POINTER_SPEED, 0)
    } catch (_: Exception) { 0 }

    fun getActive(): Profile = active
}
