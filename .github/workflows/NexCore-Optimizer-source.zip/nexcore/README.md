# NexCore Optimizer

Android app: Kotlin + Jetpack Compose, application ID `com.nexcore.optimizer`, minSdk 26, JDK 17.

## Modules
- Adaptive Performance / Thermal Guardian
- Blackbox telemetry
- Device DNA
- Smart Scan
- Network Intelligence
- Neural Engine profile recommendations
- X/Y sensitivity profiles (stored in NexCore)
- Smart DPI and resolution recommendations
- Shizuku integration for supported Android system settings

## Important input limitation
The X/Y, smooth and deadzone controls are NexCore-side game profiles. Android does not provide a public API for injecting a touch transformation into another app. The app does not inject code into Free Fire, modify its process, hook its input pipeline, or bypass anti-cheat. Android `pointer_speed` applies to mouse/stylus pointer devices, not finger touchscreen sensitivity; it is exposed separately and labelled accordingly in the implementation.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Push to `main` (or `master`).
3. Open **Actions → Build NexCore APK**.
4. Download the `NexCore-debug-*` artifact from the completed workflow.

The workflow builds `app-debug.apk` with JDK 17 and Android SDK on GitHub's runner. This source archive is not itself an installed APK.
